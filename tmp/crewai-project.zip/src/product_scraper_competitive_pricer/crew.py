import os

from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	ScrapeWebsiteTool,
	SerperDevTool,
	ScrapeElementFromWebsiteTool,
	FileReadTool
)





@CrewBase
class ProductScraperCompetitivePricerCrew:
    """ProductScraperCompetitivePricer crew"""

    
    @agent
    def advanced_product_scraping_specialist(self) -> Agent:
        
        return Agent(
            config=self.agents_config["advanced_product_scraping_specialist"],
            
            
            tools=[				ScrapeWebsiteTool(),
				ScrapeElementFromWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def advanced_data_extraction_pattern_recognition_analyst(self) -> Agent:
        
        return Agent(
            config=self.agents_config["advanced_data_extraction_pattern_recognition_analyst"],
            
            
            tools=[				FileReadTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def elite_market_intelligence_dynamic_pricing_specialist(self) -> Agent:
        
        return Agent(
            config=self.agents_config["elite_market_intelligence_dynamic_pricing_specialist"],
            
            
            tools=[				SerperDevTool(),
				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def advanced_data_engineering_e_commerce_integration_specialist(self) -> Agent:
        
        return Agent(
            config=self.agents_config["advanced_data_engineering_e_commerce_integration_specialist"],
            
            
            tools=[				FileReadTool(),
				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    

    
    @task
    def real_product_data_extraction_from_happy_homes(self) -> Task:
        return Task(
            config=self.tasks_config["real_product_data_extraction_from_happy_homes"],
            markdown=False,
            
            
        )
    
    @task
    def precise_retail_code_analysis_cost_calculation(self) -> Task:
        return Task(
            config=self.tasks_config["precise_retail_code_analysis_cost_calculation"],
            markdown=False,
            
            
        )
    
    @task
    def strategic_market_intelligence_dynamic_pricing_engine(self) -> Task:
        return Task(
            config=self.tasks_config["strategic_market_intelligence_dynamic_pricing_engine"],
            markdown=False,
            
            
        )
    
    @task
    def generate_accurate_product_pricing_spreadsheet(self) -> Task:
        return Task(
            config=self.tasks_config["generate_accurate_product_pricing_spreadsheet"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the ProductScraperCompetitivePricer crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
            chat_llm=LLM(model="openai/gpt-4o-mini"),
        )


